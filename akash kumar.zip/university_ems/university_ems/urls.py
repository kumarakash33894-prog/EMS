from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('events.urls')),
]
admin.site.site_header = "SGRR University Event Management Admin"
admin.site.site_title = "SGRR University Event Management Portal"
admin.site.index_title = "Welcome to SGRR University Event Management Administration"