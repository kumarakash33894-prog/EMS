from django.db import models


class Course(models.Model):
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=20, blank=True, null=True)

    def __str__(self):
        return f"{self.name} ({self.code})" if self.code else self.name


class StudentClass(models.Model):
    name = models.CharField(max_length=100)
    semester = models.PositiveIntegerField(default=1)
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='classes')

    def __str__(self):
        return f"{self.name} - Sem {self.semester}"


class Event(models.Model):
    EVENT_TYPES = [
        ('seminar', 'Seminar'),
        ('event', 'Event'),
        ('competition', 'Competition'),
        ('workshop', 'Workshop'),
        ('class_activity', 'Class Activity'),
    ]

    title = models.CharField(max_length=200)
    event_type = models.CharField(max_length=20, choices=EVENT_TYPES)
    description = models.TextField()
    venue = models.CharField(max_length=200)
    date = models.DateField()
    start_time = models.TimeField(blank=True, null=True)
    end_time = models.TimeField(blank=True, null=True)
    related_class = models.ForeignKey(
        StudentClass,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='events'
    )
    expected_audience = models.PositiveIntegerField(default=0)

    def __str__(self):
        return self.title


class Person(models.Model):
    ROLE_TYPES = [
        ('host', 'Host'),
        ('judge', 'Judge'),
        ('guest', 'Guest'),
        ('participant', 'Participant'),
        ('audience', 'Audience'),
        ('organizer', 'Organizer'),
    ]

    name = models.CharField(max_length=100)
    email = models.EmailField(blank=True, null=True)
    phone = models.CharField(max_length=15, blank=True, null=True)
    role = models.CharField(max_length=20, choices=ROLE_TYPES)
    student_class = models.ForeignKey(
        StudentClass,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='people'
    )

    def __str__(self):
        return f"{self.name} ({self.role})"


class Attendance(models.Model):
    STATUS_TYPES = [
        ('registered', 'Registered'),
        ('present', 'Present'),
        ('absent', 'Absent'),
        ('cancelled', 'Cancelled'),
    ]

    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name='attendance_records')
    person = models.ForeignKey(Person, on_delete=models.CASCADE, related_name='attendance_records')
    status = models.CharField(max_length=20, choices=STATUS_TYPES, default='registered')
    registered_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('event', 'person')

    def __str__(self):
        return f"{self.person.name} - {self.event.title} - {self.status}"


class Winner(models.Model):
    POSITION_TYPES = [
        ('1st', '1st'),
        ('2nd', '2nd'),
        ('3rd', '3rd'),
    ]

    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name='winners')
    person = models.ForeignKey(Person, on_delete=models.CASCADE, related_name='winner_records')
    position = models.CharField(max_length=10, choices=POSITION_TYPES)
    prize = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        unique_together = ('event', 'position')

    def __str__(self):
        return f"{self.event.title} - {self.position} - {self.person.name}"
from django.db import models

class Judge(models.Model):
    event = models.ForeignKey('Event', on_delete=models.CASCADE, related_name='judges')
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=15, blank=True, null=True)
    organization = models.CharField(max_length=150, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name