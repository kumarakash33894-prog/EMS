from django.urls import path
from . import views

urlpatterns = [
    path('', views.event_list, name='event_list'),
    path('event/add/', views.event_add, name='event_add'),
    path('person/add/', views.person_add, name='person_add'),
    path('attendance/add/', views.attendance_add, name='attendance_add'),
    path('event/<int:id>/', views.event_detail, name='event_detail'),
]
