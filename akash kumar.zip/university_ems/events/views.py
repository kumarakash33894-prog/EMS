from django.shortcuts import render, redirect, get_object_or_404
from .models import Event
from .forms import EventForm, PersonForm, AttendanceForm


def event_list(request):
    events = Event.objects.all().order_by('-date')
    return render(request, 'events/event_list.html', {'events': events})


def event_detail(request, id):
    event = get_object_or_404(Event, id=id)

    context = {
        'event': event,
        'audience_records': event.attendance_records.filter(person__role='audience'),
        'participant_records': event.attendance_records.filter(person__role='participant'),
        'host_records': event.attendance_records.filter(person__role='host'),
        'judge_records': event.attendance_records.filter(person__role='judge'),
        'guest_records': event.attendance_records.filter(person__role='guest'),
        'organizer_records': event.attendance_records.filter(person__role='organizer'),
    }
    return render(request, 'events/event_detail.html', context)


def event_add(request):
    if request.method == 'POST':
        form = EventForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('event_list')
    else:
        form = EventForm()
    return render(request, 'events/event_form.html', {'form': form})


def person_add(request):
    if request.method == 'POST':
        form = PersonForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('event_list')
    else:
        form = PersonForm()
    return render(request, 'events/person_form.html', {'form': form})


def attendance_add(request):
    if request.method == 'POST':
        form = AttendanceForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('event_list')
    else:
        form = AttendanceForm()
    return render(request, 'events/attendance_form.html', {'form': form})
