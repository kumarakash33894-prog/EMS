from django import forms
from .models import Event, Person, Attendance


class EventForm(forms.ModelForm):
    class Meta:
        model = Event
        fields = [
            'title', 'event_type', 'description', 'venue', 'date',
            'start_time', 'end_time', 'related_class', 'expected_audience'
        ]
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date'}),
            'start_time': forms.TimeInput(attrs={'type': 'time'}),
            'end_time': forms.TimeInput(attrs={'type': 'time'}),
        }


class PersonForm(forms.ModelForm):
    class Meta:
        model = Person
        fields = ['name', 'email', 'phone', 'role', 'student_class']


class AttendanceForm(forms.ModelForm):
    class Meta:
        model = Attendance
        fields = ['event', 'person', 'status']
