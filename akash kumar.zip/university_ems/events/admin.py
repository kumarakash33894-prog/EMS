from django.contrib import admin
from .models import Course, StudentClass, Event, Person, Attendance, Winner,Judge


@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ['name', 'code']


@admin.register(StudentClass)
class StudentClassAdmin(admin.ModelAdmin):
    list_display = ['name', 'semester', 'course']
    list_filter = ['course', 'semester']


@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display = ['title', 'event_type', 'venue', 'date', 'related_class', 'expected_audience']
    list_filter = ['event_type', 'date', 'related_class']
    search_fields = ['title', 'venue']


@admin.register(Person)
class PersonAdmin(admin.ModelAdmin):
    list_display = ['name', 'role', 'email', 'student_class']
    list_filter = ['role', 'student_class']
    search_fields = ['name', 'email']


@admin.register(Attendance)
class AttendanceAdmin(admin.ModelAdmin):
    list_display = ['event', 'person', 'status']
    list_filter = ['status', 'event']


@admin.register(Winner)
class WinnerAdmin(admin.ModelAdmin):
    list_display = ['event', 'person', 'position', 'prize']
    list_filter = ['position', 'event']

@admin.register(Judge)
class JudgeAdmin(admin.ModelAdmin):
    list_display = ['name', 'email', 'organization']
    list_filter = ['organization']

